﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontToBack.DAL;
using FrontToBack.Models;
using Microsoft.AspNetCore.Mvc;

namespace FrontToBack.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class StudentController : Controller
    {
        private readonly AppDbContext _db;
        public StudentController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            return View(_db.Students);
        }

        public IActionResult Detail(int id)
        {
            Student stu = _db.Students.FirstOrDefault(s => s.Id == id);
            if (stu == null)
            {
                return NotFound();
            }
            return View(stu);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Student stu)
        {
            //Model binding
            if (!ModelState.IsValid)
            {
                return View(stu);
            }

            await _db.Students.AddAsync(stu);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Delete(int id)
        {
            Student stu = _db.Students.FirstOrDefault(s => s.Id == id);
            if (stu == null)
            {
                return NotFound();
            }
            return View(stu);
        }

        [HttpPost]
        [ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeletePost(int id)
        {
            Student stu = _db.Students.FirstOrDefault(s => s.Id == id);
            if (stu == null)
            {
                return NotFound();
            }
            _db.Students.Remove(stu);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}